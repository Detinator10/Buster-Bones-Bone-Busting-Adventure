Detlef Knauss and Theo Gregersen
Grade 10
Computer Game Simulation Programming
International Community School, Kirkland

Double click the file named 'Viking!' (not the folder named the same) and click the play button in the popup.

*the folder 'Viking!_Data' is required for the program to run